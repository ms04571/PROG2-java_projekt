package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import entity.*;

@SuppressWarnings("serial")
public class GamePanel extends JPanel implements Runnable{
	
	public final int screenWidth = 1280;
	public final int screenHeight = 720;
	public final int FPS = 60;  //se lahko spreminja
	
	public boolean drawHitbox = false;
	public int timeSinceStart;
	public int score;
	
	// Game State
	public int gameState = 3;
	public final int playState = 1;
	public final int pauseState = 2;
	public final int menuState = 3;
	public final int deathState = 4;

	int spawnRate = 5; 
	UI ui = new UI(this);
	Font font = new Font("Arian", Font.BOLD, 20);
	KeyHandler keyHandler = new KeyHandler(this);
	Thread thread;
	Player player;
	List<Projectile> projectiles;
	Map<Projectile, Integer> deathAnimations;
	BufferedImage explosion;

	public GamePanel() {
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		this.setBackground(Color.gray);
		this.setDoubleBuffered(true);
		this.addKeyListener(keyHandler);
		this.setFocusable(true);
		try {
			this.explosion = ImageIO.read(new File("res", "explosion.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void startThread() {			
		thread = new Thread(this);
		thread.start();
	}
	
	//nastavi začetne parametre igre
	public void setStart() {
		player = new Player(this, keyHandler);
		projectiles = new ArrayList<Projectile>();
		deathAnimations = new HashMap<Projectile, Integer>();
		timeSinceStart = 0;
		score = 0;
		
		Vector2D v = new Vector2D(screenWidth * 0.25, screenHeight * 0.8);
		MissileBasic m = new MissileBasic(v, new Vector2D(0, -1), 150, 10, this, player, 2.0 / FPS);
		projectiles.add(m);
		
		v = new Vector2D(screenWidth * 0.75, screenHeight * 0.8);
		m = new MissileBasic(v, new Vector2D(0, -1), 150, 10, this, player, 2.0 / FPS);
		projectiles.add(m);
	}
	
	//lepši izpis časa
	public String timeToString() {
		int min = timeSinceStart / 60;
		int sec = timeSinceStart - min * 60;
		return String.format("%d:%02d", min, sec);
	}
		
	
	@Override
	public void run() {
		setStart();
		double drawInterval = 1000000000 / FPS;
		long lastTime = System.nanoTime();
		double delta = 0.0;
		long currentTime;
		int frames = 0;
		long timer = 0;
		
		

		//delta metoda za igralni loop (znana metoda iz spleta)
		while (thread != null) {
			currentTime = System.nanoTime();
			
			delta += (currentTime - lastTime) / drawInterval;
			timer += (currentTime - lastTime);
			lastTime = currentTime;
			
			if (delta >= 1) {
				update();
				repaint();
				delta--;
				frames++;
			}
			
			if (timer >= 1000000000) {
				System.out.println("FPS:" + frames);
				frames = 0;
				timer = 0;
				
				if (gameState == playState) {
					timeSinceStart++;
					spawn(spawnRate);
				}

			}


				
		}
			
	}
		
	//razne update metode
	public void update() {
		
		if (gameState == playState) {
			player.update();
			updateProjectiles();
			checkPlayerCollisions();
			checkProjectileCollisions();
		}

	}
	
	//razne paint metode
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setColor(Color.white);
		g2d.setStroke(new BasicStroke(1.0f));
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		
		//projectiles
		drawProjectiles(g2d, drawHitbox);
		drawDeathAnimations(g2d);

		//player
		player.draw(g2d, drawHitbox);

		//UI
		ui.draw(g2d);
		
		g2d.dispose();
	}
		
	//zbriše tiste objekte ki so se zaleteli
	public void checkProjectileCollisions() {
		List<Integer> collided = new ArrayList<Integer>(); //indeksi vseh zaletelih
		if (projectiles.size() > 1) {
			for (int i = 0; i < projectiles.size() - 1; i++) {
				for (int j = i + 1; j < projectiles.size(); j++) {
					if (projectiles.get(i).collidesWith(projectiles.get(j))) {
						collided.add(i);
						collided.add(j);
						deathAnimations.put(projectiles.get(i), FPS / 2);
						deathAnimations.put(projectiles.get(j), FPS / 2);
						score += 2;
					}
				}
			}
		}
		//odstrani vse ki si se zaleteli (našel na spletu)
		collided.stream().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).forEach(projectiles::remove);

	}
		
	//posodobi vse nevarne objekte
	public void updateProjectiles() {
		Iterator<Projectile> i = projectiles.iterator();
		while (i.hasNext()) {
			Projectile projectile = i.next();
			projectile.update();
			//če so predaleč izven okna jih odstrani (namenjeno za objekte Bullet ki ne zavijajo)
			if (projectile.isOutOfBounds(200.0)) {
				i.remove();
			}
		}

	}
	
	//gleda če se igralec zaleti ali gre izven okna
	public void checkPlayerCollisions() {
		for (int i = 0; i < projectiles.size(); i++) {
			if (projectiles.get(i).collidesWith(player))
				gameState = deathState;
		}
		
		if (player.isOutOfBounds(0.0))
		gameState = deathState;
	}
	
	public void drawProjectiles(Graphics2D g2d, boolean drawHitbox) {
		for (int i = 0; i < projectiles.size(); i++) {
			projectiles.get(i).draw(g2d, drawHitbox);
		}
	}
	
	//animacija za uničen objekt
	//uničeni objekti se hranijo v slovarju kjer je vrednost enaka preostalemu času animacije
	//v tem primeru je to samo ena slika
	public void drawDeathAnimations(Graphics2D g2d) {
		for (Map.Entry<Projectile, Integer> entry : deathAnimations.entrySet()) {
			int tick = entry.getValue();
			Vector2D position = entry.getKey().getPosition();
			AffineTransform aT = new AffineTransform();
			aT.translate(position.getX() - 16, position.getY() - 16);
			g2d.drawImage(explosion, aT, null);
			entry.setValue(tick - 1);
		}
		deathAnimations.entrySet().removeIf(e -> e.getValue() == 0);
	}
	
	
	//ustvari nove objekte izven okna
	public void spawn(int spawnRate) {
		if (timeSinceStart % spawnRate == 0) {
			double border = 200;
			double x,y;
			
			//interval hitrosti je odvisen od časa igranja
			double maxSpeed = timeSinceStart / 300.0 * 200 + 200;
			double minSpeed = -timeSinceStart / 300.0 * 100 + 200;
			double speed = Math.random() * (maxSpeed - minSpeed) + minSpeed;
			
			//interval kotne hitrosti je odvisen od časa igranja
			double maxAngularVelocity = timeSinceStart / 300.0 * 2 + 2;
			double minAngularVelocity = timeSinceStart / 300.0 * 2 + 1;
			double angularVelocity = Math.random() * (maxAngularVelocity - minAngularVelocity) + minAngularVelocity;
			
			if (Math.random() < 0.5) {
				if (Math.random() < 0.5) 
					x = -border;
				else
					x = screenWidth + 50.0;
				y = Math.random() * (screenHeight +100) - border ;
			}
			else {
				if (Math.random() < 0.5) 
					y = -border;
				else
					y = screenHeight + border;
				x = Math.random() * (screenWidth +100) - border ;
			}
			Vector2D v = new Vector2D(x, y);
			Vector2D d = player.getPosition().add(v.scale(-1)).normalized();
			Projectile m = null;
			
			//vsak tip enako verjeten
			//nekateri imajo povečane 
			int choise = (int)(Math.random() * 4);
			switch (choise) {
			case 0:
				m = new MissileBasic(v, d, speed, 10.0 , this, player, angularVelocity * 2 / FPS);
				break;
			case 1:
				m = new MissilePrediction(v, d, speed * 1.5 , 10.0 , this, player, angularVelocity * 1.5 / FPS);
				break;
			case 2:
				m = new MissileProportional(v, d, speed , 10.0 , this, player, angularVelocity * 1.5 / FPS);
				break;
			case 3:
				m = new Bullet(v, d, speed * 2, 7.0 , this, player);
				break;
			}
			projectiles.add(m);
			
		}
	}
	
	
	
}
