package main;

public class Vector2D {
	
	private double x;
	private double y;
	
	public Vector2D(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setX(double newX) {
		x=newX;
	}
	
	public void setY(double newY) {
		y=newY;
	}
	
	public Vector2D clone() {
		return this;
	}
	
	public double magnitude() {
		return Math.sqrt(dot(this, this));
	}
	
	//vrne normiran vektor
	public Vector2D normalized() {
		double magnitude = this.magnitude();
		return new Vector2D(x / magnitude, y / magnitude);
	}
	
	//normira trenutni vektor
	public void normalize() {
		double magnitude = this.magnitude();
		this.x = x / magnitude;
		this.y = y / magnitude;
	}
	
	public Vector2D add(Vector2D v) {
		return new Vector2D(x + v.getX(), y + v.getY());
	}
	
	public Vector2D scale(double s) {
		return new Vector2D(x * s, y * s);
	}

	public static double dot(Vector2D v1, Vector2D v2) {
		return v1.getX() * v2.getX() + v1.getY() * v2.getY(); 
	}
	
	public double direction() {
		return Math.atan2(y, x);
	}
	
	public static double angle(Vector2D v1, Vector2D v2){
		double y = v2.getY() * v1.getX() - v2.getX() * v1.getY();
		double x = v2.getX() * v1.getX() + v2.getY() * v1.getY();
		return Math.atan2(y, x);
	}
	
	//vrne zarotiran vektor
	public Vector2D rotated(double angle) {
		double cos = Math.cos(angle);
		double sin = Math.sin(angle);
		return new Vector2D(x * cos - y * sin, x * sin + y * cos);
	}
	
	//rotira trenutni vektor
	public void rotate(double angle) {
		double cos = Math.cos(angle);
		double sin = Math.sin(angle);
		x = x * cos - y * sin;
		y = x * sin + y * cos;
	}
	
	public String toString() {
		return String.format("X:%.2f Y:%.2f",x,y);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
