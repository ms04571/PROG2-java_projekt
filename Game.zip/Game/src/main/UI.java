package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class UI {
	
	GamePanel gp;
	
	Font menuFont = new Font("Arian", Font.BOLD, 50);
	
	public UI(GamePanel gp) {
		this.gp = gp;
	}
	
	
	public void draw(Graphics2D g2d) {
		
		if (gp.gameState == gp.playState) {
			drawUI(g2d);
		}
		
		if (gp.gameState == gp.pauseState) {
			drawPauseMenu(g2d);
		}
		
		if (gp.gameState == gp.menuState) {
			drawMainMenu(g2d);
		}
		
		if (gp.gameState == gp.deathState) {
			drawDeathMenu(g2d);
		}
	}
	
	
	
	public void drawMainMenu(Graphics2D g2d) {
		drawMenuWindow(g2d);
		
		int y = gp.screenHeight / 2;
		g2d.setFont(menuFont);
		String text = "Start [SPACE]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y - 25);
		text = "Quit [Q]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y + 55);

		
		
	}
	
	public void drawUI(Graphics2D g2d) {
		double speedRatio = gp.player.getSpeed() / gp.player.getMaxSpeed();
		g2d.setColor(Color.GREEN);
		g2d.fillRect(20, gp.screenHeight - 10 - (int)(100 * speedRatio), 30, (int)(100 * speedRatio));
		g2d.setColor(Color.BLACK);
		g2d.setStroke(new BasicStroke(4.0f));
		g2d.drawRect(20, gp.screenHeight - 110, 30, 100);
		
		g2d.setFont(gp.font);
		String text = "speed";
		g2d.drawString(text, 5, gp.screenHeight - 120);
		text = "Pause [ESC]";
		g2d.drawString(text, gp.screenWidth - 120, 20);
		text = "score: " + gp.score;
		g2d.drawString(text, 5, 20);
		text = gp.timeToString();
		g2d.drawString(text, getXForCenterScreen(text, g2d), 20);
	}
	
	
	public void drawPauseMenu(Graphics2D g2d) {
		drawMenuWindow(g2d);
		
		int dy = gp.screenHeight / 10;
		int y = gp.screenHeight / 4 + dy + 15;
		
		g2d.setFont(menuFont);
		String text = "Resume [ESC]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;
		text = "Restart [R]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;
		text = "Toggle hitbox [T]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;
		text = "Quit [Q]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);

	}
	
	public void drawDeathMenu(Graphics2D g2d) {
		drawMenuWindow(g2d);
		
		int dy = gp.screenHeight / 10;
		int y = gp.screenHeight / 4 + dy + 15;
		
		g2d.setFont(menuFont);
		String text = "Score: " + gp.score;
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;
		text = "Time " + gp.timeToString();
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;
		text = "Restart [R]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;
		text = "Quit [Q]";
		g2d.drawString(text, getXForCenterScreen(text, g2d), y);
		y += dy;

	}
	
	public void drawMenuWindow(Graphics2D g2d) {
		g2d.setColor(new Color(0, 0, 0, 150));
		g2d.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
		g2d.setColor(new Color(0, 0, 0, 200));
		g2d.fillRect(gp.screenWidth / 4, gp.screenHeight / 4, gp.screenWidth / 2, gp.screenHeight / 2);
		g2d.setColor(Color.WHITE);
		g2d.setStroke(new BasicStroke(4.0f));
		g2d.drawRect(gp.screenWidth / 4, gp.screenHeight / 4, gp.screenWidth / 2, gp.screenHeight / 2);
	}
	
	public int getXForCenterScreen(String s, Graphics2D g2d) {
		int length = (int)g2d.getFontMetrics().getStringBounds(s,g2d).getWidth();
		return gp.screenWidth / 2 - length / 2;
	}
	

	
	
	
}
