package entity;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.Vector2D;

public class Bullet extends Projectile {
	
	
	public Bullet(Vector2D position, Vector2D direction, double speed, double hitRadius, GamePanel gp, Player player) {
		super(position, direction, speed, hitRadius, gp, player);
		try {
			this.image = ImageIO.read(new File("res", "bullet.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	

	

}
