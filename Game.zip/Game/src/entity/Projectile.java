package entity;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.Vector2D;

public abstract class Projectile extends Entity{
	
	//abstrakten nadrazred vseh nevarnih objektov
	
	protected Player player;
	protected BufferedImage warning;
	
	public Projectile(Vector2D position, Vector2D direction, double speed, double hitRadius, GamePanel gp, Player player) {
		super();
		this.position = position;
		this.direction = direction;
		this.speed = speed;
		this.hitRadius = hitRadius;
		this.gp = gp;
		this.player = player;
	
		try {
			this.warning = ImageIO.read(new File("res", "warning.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void draw(Graphics2D g2d, boolean drawHitbox) {
		super.draw(g2d,drawHitbox);
		
		// če je izven okna pokaže klicaj na robu okna tocno med igralcem in raketo
		if (this.isOutOfBounds(0.0)) {
			Vector2D vector = player.getPosition().add(position.scale(-1));
			double x0 = position.getX();
			double y0 = position.getY();
			double dx = vector.getX();
			double dy = vector.getY();
			double t;
			if (dy > 0) {
				t = (16 - y0) / dy;
				double x = x0 + t * dx;
				if (x > gp.screenWidth - 16) 
					t = (gp.screenWidth - 16 - x0) / dx;
				else if (x < 16) 
					t = (16 - x0) / dx;
			}
			else {
				t = (gp.screenHeight - 16 - y0) / dy;
				double x = x0 + t * dx;
				if (x > gp.screenWidth - 16) 
					t = (gp.screenWidth - 16 - x0) / dx;
				else if (x < 16) 
					t = (16 - x0) / dx;
			}
			Vector2D v = position.add(vector.scale(t));
			AffineTransform aT = new AffineTransform();
			aT.translate(v.getX() - 16, v.getY() - 16);
			g2d.drawImage(warning, aT, null);
			
		}
	}

	
}
