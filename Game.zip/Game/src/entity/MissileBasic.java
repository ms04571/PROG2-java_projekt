package entity;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.Vector2D;

public class MissileBasic extends Projectile{
	

	protected Double angularVelocity;
	
	public MissileBasic(Vector2D position, Vector2D direction, double speed, double hitRadius, GamePanel gp, Player player, double angularVelocity) {
		super(position, direction, speed, hitRadius, gp, player);
		try {
			this.image = ImageIO.read(new File("res", "missile2.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.angularVelocity = angularVelocity;
		
	}

	@Override
	public void update() {
		//enostavno se obrene proti igralcu
		Vector2D pointVector = player.getPosition().add(position.scale(-1));
		double angle = Vector2D.angle(direction, pointVector);
		direction.rotate(Math.min(angularVelocity, Math.max(-angularVelocity, angle)));
		direction.normalize();
		super.update();
		
	}

}
