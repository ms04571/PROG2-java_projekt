package entity;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.Vector2D;

public class MissilePrediction extends Projectile{


	protected Double angularVelocity;

	
	public MissilePrediction(Vector2D position, Vector2D direction, double speed, double hitRadius, GamePanel gp, Player player, double angularVelocity) {
		super(position, direction, speed, hitRadius, gp, player);
		try {
			this.image = ImageIO.read(new File("res", "missile3.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.angularVelocity = angularVelocity;
	}
	
	@Override
	public void update() {
		//izračuna kam se mora obrniti da trči v igralca
		Vector2D vector = player.getPosition().add(position.scale(-1));
		double distance = vector.magnitude();
		Vector2D playerVelocity = player.getDirection().scale(player.getSpeed());
		Vector2D velocity = direction.scale(speed);
		double relSpeed = speed - Vector2D.dot(vector.normalized(), velocity);
		Vector2D pointVector = (player.getPosition().add(playerVelocity.scale(distance / (relSpeed) )).add(position.scale(-1)));
		double angle = Vector2D.angle(direction, pointVector);
		direction.rotate(Math.min(angularVelocity, Math.max(-angularVelocity, angle * gp.FPS)));
		direction.normalize();
		super.update();
	}
	
	
	
	
	
	
}
