package entity;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.Vector2D;

public class MissileProportional extends Projectile{

	protected Double angularVelocity;
	protected Vector2D previousPosition;
	
	public MissileProportional(Vector2D position, Vector2D direction, double speed, double hitRadius, GamePanel gp, Player player, double angularVelocity) {
		super(position, direction, speed, hitRadius, gp, player);
		try {
			this.image = ImageIO.read(new File("res", "missile1.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		this.angularVelocity = angularVelocity;
		this.previousPosition = position.clone();
	}
	
	@Override
	public void update() {
		//gleda v katero smer se premika igralec relativno na sebe in zavije v tisto smer
		Vector2D curentVector = player.getPosition().add(position.scale(-1));
		Vector2D previousVector = player.getPreviousPosition().add(previousPosition.scale(-1));
		double angle = Vector2D.angle(previousVector, curentVector);
		Vector2D pointVector = curentVector.rotated(Math.min(Math.PI * 0.4, Math.max(-Math.PI * 0.4, angle * gp.FPS * 2)));
		angle = Vector2D.angle(direction, pointVector);
		direction.rotate(Math.min(angularVelocity, Math.max(-angularVelocity, angle )));
		direction.normalize();

		previousPosition = position.clone();
		super.update();
		
	}
	
	
	
}
