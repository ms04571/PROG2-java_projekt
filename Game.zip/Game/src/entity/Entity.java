package entity;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;


import main.GamePanel;
import main.Vector2D;

public abstract class Entity {
	
	//abstrakten class za vse premikajoče objekte
	
	//hirarhija:                 Entity
	//							/      \
	//					    Player    Projectile   --  Bullet
	//								/     |      \     
	//					     Missile   Missile    Missile
	//                        Basic	  Prediction   Proportional
	
	protected Vector2D position;
	protected Vector2D direction;
	protected double hitRadius;
	protected BufferedImage image;
	protected GamePanel gp;
	protected double speed;


	public Entity() {
	}
	
	
	public Vector2D getPosition() {return position;}
	public Vector2D getDirection() {return direction;}
	public double getHitRadius() {return hitRadius;}
	public double getSpeed() { return speed;}
	
	
	
	
	public boolean collidesWith(Entity e) {
		Vector2D x = position.add(e.getPosition().scale(-1));
		double distanceSq = Vector2D.dot(x, x);
		double minimumDistanceSq = Math.pow(hitRadius, 2) + Math.pow(e.getHitRadius(), 2);
		if (distanceSq < minimumDistanceSq)
			return true;
		return false;
	}
	
	public  void update() {
		position = position.add(direction.scale(speed / gp.FPS));
	}
	
	public void draw(Graphics2D g2d, boolean drawHitbox) {
		AffineTransform aT = new AffineTransform();
		aT.rotate(direction.direction() + Math.PI * 0.5, position.getX() , position.getY());
		aT.translate(position.getX() - 16, position.getY() - 16);
		g2d.drawImage(image, aT, null);
		if (drawHitbox) {
			g2d.draw(new Rectangle2D.Double(position.getX(), position.getY(), 1, 1));
			g2d.setColor(Color.GREEN);
			g2d.draw(new Ellipse2D.Double(position.getX() - hitRadius, position.getY() - hitRadius, hitRadius * 2, hitRadius * 2));
			
		}
		
	}
	
	
	public boolean isOutOfBounds(double bound) {
		if (position.getX() > gp.screenWidth + bound || position.getX() < -bound || position.getY() > gp.screenHeight + bound || position.getY() < - bound) {
			return true;
		}
		return false;
	}
	
	
	
	
	
	
	
	
	
	
}
