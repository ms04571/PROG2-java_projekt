package entity;


import java.awt.geom.AffineTransform;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;
import main.Vector2D;

public class Player extends Entity{
	
	private double acceleration;
	private double angularVelocity;
	private double maxSpeed;
	private KeyHandler keyH;
	private Vector2D previousPosition;
	
	public Player(GamePanel gp, KeyHandler keyH) {
		this.gp = gp;
		this.keyH = keyH;
		setStartValues();
	}
	
	public void setStartValues() {
		try {
			image = ImageIO.read(new File("res", "player.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		hitRadius = 10.0;
		position = new Vector2D(gp.screenWidth * 0.5 + 0.5, gp.screenHeight * 0.5 + 0.5);
		previousPosition = new Vector2D(gp.screenWidth * 0.5, gp.screenHeight * 0.5);
		direction = new Vector2D(0, -1);
		acceleration = 600;
		angularVelocity = 4;
		maxSpeed = 400;
		speed = 0;
		
	}
	
	public Vector2D getPreviousPosition() {return previousPosition;}
	public double getMaxSpeed() {return maxSpeed;}
	
	public void update() {
		double correctedAcc = acceleration / gp.FPS;
		double correctedAngVel = angularVelocity / gp.FPS;
		
		//pospeševanje/pojemanje
		if (keyH.forwardPressed) {
			speed += correctedAcc;
			if (speed > maxSpeed) {
				speed = maxSpeed;
			}
		}
		if (keyH.backwardPressed) {
			speed -= correctedAcc;
			if (speed < 0.0) {
				speed = 0.0;
			}
		}
		
		//kotna hitrost je odvisna od histrosti igralca (hitrejši kot si počasneje obračaš)
		angularVelocity = Math.max(3, Math.min(7,- Math.pow((speed / 250), 4) + 7));
		
		
		//obračanje levo/desno
		AffineTransform aT = new AffineTransform();
		if (keyH.leftPressed) {
			
			direction = direction.rotated(-correctedAngVel);
			aT.rotate(-correctedAngVel, position.getX(), position.getY());
		}
		if (keyH.rightPressed) {
			direction = direction.rotated(correctedAngVel);
			aT.rotate(correctedAngVel, position.getX(), position.getY());
		}
		
		previousPosition = position.clone();
		super.update();
		

	}
	
	

	
	
	
	
	
}
